package com.example.Modpics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ModpicsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ModpicsApplication.class, args);
	}

}
