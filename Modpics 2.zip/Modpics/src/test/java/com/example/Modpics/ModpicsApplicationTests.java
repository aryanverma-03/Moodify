package com.example.Modpics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ModpicsApplicationTests {

	@Test
	void contextLoads() {
	}

}
